"""
migrar_medicos.py — Adiciona colunas faltantes na tabela medicos
Executar UMA VEZ no ambiente onde prontuario.db já existe.

Uso:
  cd C:\\pessoal\\python\\Koios
  python migrar_medicos.py
"""
import os
import sys
import sqlite3

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

# Localizar prontuario.db
CANDIDATOS = [
    os.path.join(_HERE, "prontuario", "dados", "prontuario.db"),
    os.path.join(_HERE, "database", "prontuario.db"),
    os.path.join(_HERE, "prontuario.db"),
    r"C:\pessoal\python\Koios\prontuario\dados\prontuario.db",
]
DB_PATH = None
for c in CANDIDATOS:
    if os.path.exists(c):
        DB_PATH = c
        break

if not DB_PATH:
    print("ERRO: prontuario.db não encontrado. Verifique o caminho.")
    sys.exit(1)

print(f"Banco encontrado: {DB_PATH}")

conn = sqlite3.connect(DB_PATH, timeout=30)
cur  = conn.cursor()

cur.execute("PRAGMA table_info(medicos)")
colunas = [row[1] for row in cur.fetchall()]
print(f"Colunas atuais: {colunas}")

adicionadas = []

if "especialidade" not in colunas:
    cur.execute("ALTER TABLE medicos ADD COLUMN especialidade TEXT")
    adicionadas.append("especialidade")

if "medico_solicit" not in colunas:
    cur.execute("ALTER TABLE medicos ADD COLUMN medico_solicit TEXT")
    adicionadas.append("medico_solicit")

conn.commit()
conn.close()

if adicionadas:
    print(f"✓ Colunas adicionadas: {adicionadas}")
else:
    print("✓ Nenhuma alteração necessária — colunas já existem")

print("Migração concluída.")
